-- case study idealo

create DATABASE ideo;
use ideo;

CREATE TABLE click(
    shop_id INT,
    year INT,
    isoweek INT,
    root_cat_name VARCHAR(50),
    price_bucket VARCHAR(20),
    position VARCHAR(10),
    clickouts INT,
    converted_clickout INT,
    earnings_cpc DECIMAL(10,2),
    earnings_cpo DECIMAL(10,2)
);

CREATE TABLE offer(
    shop_id INT,
    date DATE,
    root_cat_name VARCHAR(50),
    price_bucket VARCHAR(20),
    position VARCHAR(10),
    oop_offers INT
);


LOAD DATA INFILE 'C:/ProgramData/MySQLL/MySQL Server 8.0/Uploads/click.csv'
INTO TABLE click
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA INFILE 'C:/ProgramData/MySQLL/MySQL Server 8.0/Uploads/offer.csv'
INTO TABLE offer
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

--

USE ideo;

-- quick params
SET @shop_id     = 10;            -- use 463 for the other shop
SET @switch_date = '2023-08-18';  -- CPO contract start

-- monday of the “switch” week
SET @transition_week_start = DATE_SUB(@switch_date, INTERVAL WEEKDAY(@switch_date) DAY);

-- step 0: add week_start + period flags on click data
DROP TEMPORARY TABLE IF EXISTS click_enriched;
CREATE TABLE click_enriched AS
SELECT 
    c.*,
    -- week_start = monday of iso week (from year + isoweek)
    DATE_SUB(
        DATE_ADD(MAKEDATE(c.year, 1), INTERVAL (c.isoweek - 1) WEEK),
        INTERVAL WEEKDAY(
            DATE_ADD(MAKEDATE(c.year, 1), INTERVAL (c.isoweek - 1) WEEK)
        ) DAY
    ) AS week_start,
    CASE 
        WHEN DATE_SUB(
                 DATE_ADD(MAKEDATE(c.year, 1), INTERVAL (c.isoweek - 1) WEEK),
                 INTERVAL WEEKDAY(
                     DATE_ADD(MAKEDATE(c.year, 1), INTERVAL (c.isoweek - 1) WEEK)
                 ) DAY
             ) < @transition_week_start
            THEN 'Pre-CPO'
        WHEN DATE_SUB(
                 DATE_ADD(MAKEDATE(c.year, 1), INTERVAL (c.isoweek - 1) WEEK),
                 INTERVAL WEEKDAY(
                     DATE_ADD(MAKEDATE(c.year, 1), INTERVAL (c.isoweek - 1) WEEK)
                 ) DAY
             ) = @transition_week_start
            THEN 'Transition'
        ELSE 'Post-CPO'
    END AS period
FROM click c;

-- step 1: shop level view (rev + CR)
-- run once for shop_id = 10 and once for 463
SELECT
    'EXEC SUMMARY (SHOP LEVEL)' AS section,
    @shop_id                    AS shop_id,
    ROUND(SUM(CASE WHEN period = 'Pre-CPO'  THEN earnings_cpc + earnings_cpo END), 2) AS revenue_pre,
    ROUND(SUM(CASE WHEN period = 'Post-CPO' THEN earnings_cpc + earnings_cpo END), 2) AS revenue_post,
    ROUND(
        (SUM(CASE WHEN period = 'Post-CPO' THEN earnings_cpc + earnings_cpo END)
       -  SUM(CASE WHEN period = 'Pre-CPO'  THEN earnings_cpc + earnings_cpo END))
        / NULLIF(SUM(CASE WHEN period = 'Pre-CPO' THEN earnings_cpc + earnings_cpo END), 0) * 100,
        1
    ) AS revenue_growth_pct,
    ROUND(
        SUM(CASE WHEN period = 'Pre-CPO' THEN converted_clickout END)
        / NULLIF(SUM(CASE WHEN period = 'Pre-CPO' THEN clickouts END), 0),
        4
    ) AS cr_pre,
    ROUND(
        SUM(CASE WHEN period = 'Post-CPO' THEN converted_clickout END)
        / NULLIF(SUM(CASE WHEN period = 'Post-CPO' THEN clickouts END), 0),
        4
    ) AS cr_post
FROM click_enriched
WHERE shop_id = @shop_id
  AND period IN ('Pre-CPO','Post-CPO');

-- step 2: weekly trends (for charts, PPT, whatever)
SELECT
    week_start,
    @shop_id AS shop_id,
    period,
    SUM(clickouts)                   AS clickouts,
    SUM(converted_clickout)          AS conversions,
    SUM(earnings_cpc + earnings_cpo) AS total_revenue,
    SUM(converted_clickout) / NULLIF(SUM(clickouts), 0)          AS conversion_rate,
    SUM(earnings_cpc + earnings_cpo) / NULLIF(SUM(clickouts), 0) AS rpc
FROM click_enriched
WHERE shop_id = @shop_id
GROUP BY week_start, period
ORDER BY week_start;

-- step 3: segment view (category + price bucket)
SELECT
    root_cat_name,
    price_bucket,
    ROUND(SUM(CASE WHEN period = 'Pre-CPO'  THEN earnings_cpc + earnings_cpo END), 2) AS revenue_pre,
    ROUND(SUM(CASE WHEN period = 'Post-CPO' THEN earnings_cpc + earnings_cpo END), 2) AS revenue_post,
    ROUND(
        SUM(CASE WHEN period = 'Post-CPO' THEN earnings_cpc + earnings_cpo END)
      - SUM(CASE WHEN period = 'Pre-CPO'  THEN earnings_cpc + earnings_cpo END),
        2
    ) AS revenue_diff,
    ROUND(
        (SUM(CASE WHEN period = 'Post-CPO' THEN earnings_cpc + earnings_cpo END)
       -  SUM(CASE WHEN period = 'Pre-CPO'  THEN earnings_cpc + earnings_cpo END))
        / NULLIF(SUM(CASE WHEN period = 'Pre-CPO' THEN earnings_cpc + earnings_cpo END), 0) * 100,
        1
    ) AS pct_change
FROM click_enriched
WHERE shop_id = @shop_id
  AND period IN ('Pre-CPO','Post-CPO')
GROUP BY root_cat_name, price_bucket
ORDER BY revenue_diff DESC;

-- step 4: inventory commitment (avg OOP offers)
SELECT
    'INVENTORY COMMITMENT' AS section,
    @shop_id               AS shop_id,
    ROUND(AVG(CASE WHEN period = 'Pre-CPO'  THEN total_oop_offers END), 0) AS avg_oop_pre,
    ROUND(AVG(CASE WHEN period = 'Post-CPO' THEN total_oop_offers END), 0) AS avg_oop_post,
    ROUND(
        (AVG(CASE WHEN period = 'Post-CPO' THEN total_oop_offers END)
       - AVG(CASE WHEN period = 'Pre-CPO'  THEN total_oop_offers END))
        / NULLIF(AVG(CASE WHEN period = 'Pre-CPO' THEN total_oop_offers END), 0) * 100,
        1
    ) AS oop_growth_pct
FROM (
    SELECT
        o.shop_id,
        -- week_start directly from date’s monday
        DATE_SUB(o.date, INTERVAL WEEKDAY(o.date) DAY) AS week_start,
        CASE 
            WHEN DATE_SUB(o.date, INTERVAL WEEKDAY(o.date) DAY) <  @transition_week_start THEN 'Pre-CPO'
            WHEN DATE_SUB(o.date, INTERVAL WEEKDAY(o.date) DAY) =  @transition_week_start THEN 'Transition'
            ELSE 'Post-CPO'
        END AS period,
        SUM(oop_offers) AS total_oop_offers
    FROM offer o
    WHERE o.shop_id = @shop_id
    GROUP BY 
        o.shop_id,
        DATE_SUB(o.date, INTERVAL WEEKDAY(o.date) DAY),
        CASE 
            WHEN DATE_SUB(o.date, INTERVAL WEEKDAY(o.date) DAY) <  @transition_week_start THEN 'Pre-CPO'
            WHEN DATE_SUB(o.date, INTERVAL WEEKDAY(o.date) DAY) =  @transition_week_start THEN 'Transition'
            ELSE 'Post-CPO'
        END
) t
WHERE period IN ('Pre-CPO','Post-CPO');

-- step 5: partner vs rest of platform

-- 5a: raw revenue split
SELECT
    'PLATFORM IMPACT – REVENUE' AS section,
    CASE 
        WHEN shop_id IN (10,463) THEN 'DroptLikeItsHot'
        ELSE 'Other shops'
    END AS grp,
    period,
    SUM(clickouts)                   AS total_clickouts,
    SUM(converted_clickout)          AS total_conversions,
    SUM(earnings_cpc + earnings_cpo) AS total_revenue
FROM click_enriched
WHERE period IN ('Pre-CPO','Post-CPO')
GROUP BY grp, period
ORDER BY period, grp;

-- 5b: revenue share inside each period
WITH platform_group AS (
    SELECT
        CASE 
            WHEN shop_id IN (10,463) THEN 'DroptLikeItsHot'
            ELSE 'Other shops'
        END AS grp,
        period,
        SUM(earnings_cpc + earnings_cpo) AS total_revenue
    FROM click_enriched
    WHERE period IN ('Pre-CPO','Post-CPO')
    GROUP BY grp, period
),
platform_totals AS (
    SELECT
        period,
        SUM(total_revenue) AS period_total_revenue
    FROM platform_group
    GROUP BY period
)
SELECT
    'PLATFORM IMPACT – REVENUE SHARE' AS section,
    g.grp,
    g.period,
    ROUND(g.total_revenue, 2)                AS revenue,
    ROUND(p.period_total_revenue, 2)         AS period_total_revenue,
    ROUND(g.total_revenue / NULLIF(p.period_total_revenue,0), 4) AS revenue_share
FROM platform_group g
JOIN platform_totals p USING (period)
ORDER BY g.period, g.grp;

-- step 6: category benchmarks (expected KPIs for 10+463)
SELECT
    'CATEGORY BENCHMARKS (BOTH SHOPS 10 & 463)' AS section,
    root_cat_name,
    price_bucket,
    period,
    SUM(clickouts)                   AS total_clicks,
    SUM(converted_clickout)          AS total_conversions,
    SUM(earnings_cpc + earnings_cpo) AS total_revenue,
    SUM(converted_clickout) / NULLIF(SUM(clickouts), 0)              AS expected_cr,
    SUM(earnings_cpc + earnings_cpo) / NULLIF(SUM(clickouts), 0)     AS expected_rpc,
    SUM(earnings_cpc + earnings_cpo) / NULLIF(SUM(converted_clickout), 0) AS expected_rpo
FROM click_enriched
WHERE shop_id IN (10,463)
  AND period IN ('Pre-CPO','Post-CPO')
GROUP BY root_cat_name, price_bucket, period
ORDER BY root_cat_name, price_bucket, period;
